import LayoutSide from "../layout/LayoutSide";
import { Typography, Grid, Box } from "@mui/material";

const Dashboard = () => {
  return (
   
   
    <LayoutSide />
    
  
  );
};
export default Dashboard;
