import { Link } from "@mui/material";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import { createTheme, ThemeProvider, styled } from "@mui/material/styles";
import { Grid, Typography } from "@mui/material";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Button from "@mui/material/Button";
import { BookmarkBorder, AttachMoney, LocationOn } from "@mui/icons-material";

export default function GastMainBox() {
  return (
    <Box>
      <Typography
        sx={{
          display: "flex",
          textTransform: "uppercase",
          fontWeight: "bold",
          fontSize: 16,
          mt: "20px",
          mb:"15px"
        }}
      >
        Recommenend event for you
      </Typography>
      <Box
        sx={{
          justifyContent: "center",
          display: "flex",
          flexWrap: "wrap",
          "& > :not(style)": {
            m: 1,
            width: 150,
            height: 150,
          },
        }}
      >
        <img
          src="https://www.goethe.de/resources/files/jpg1159/press-image-3-anselm-kiefer-essence-eksistence-artipelag-photo-jean-baptiste-beranger1-formatkey-jpg-w1022.jpg"
          className="Category-img"
          alt="Anselm Kiefer Austellung"
        />

        <img
          src="https://www.goethe.de/resources/files/jpg1159/press-image-3-anselm-kiefer-essence-eksistence-artipelag-photo-jean-baptiste-beranger1-formatkey-jpg-w1022.jpg"
          className="Category-img"
          alt="Anselm Kiefer Austellung"
        />

        <img
          src="https://www.goethe.de/resources/files/jpg1159/press-image-3-anselm-kiefer-essence-eksistence-artipelag-photo-jean-baptiste-beranger1-formatkey-jpg-w1022.jpg"
          className="Category-img"
          alt="Anselm Kiefer Austellung"
        />

        <img
          src="https://www.goethe.de/resources/files/jpg1159/press-image-3-anselm-kiefer-essence-eksistence-artipelag-photo-jean-baptiste-beranger1-formatkey-jpg-w1022.jpg"
          className="Category-img"
          alt="Anselm Kiefer Austellung"
        />
        <Paper variant="outlined" square />

        <Paper variant="outlined" square />
        <Paper variant="outlined" square />
        <Paper variant="outlined" square />
        <Paper variant="outlined" square />
        <Paper variant="outlined" square />
      </Box>

      <Typography
        sx={{
          display: "flex",
          textTransform: "uppercase",
          fontWeight: "bold",
          fontSize: 16,
          mt: "20px",
          mb:"15px"
        }}
      >
        Today
      </Typography>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-evenly",
          gap: "10px",
          flexWrap: "wrap",
        }}
      >
        {/* <Grid item xs={4}>
        <Card elevation={1}>
        <CardContent>

        <Box sx={{alignItems:"left", display:"inline-flex" }}>
        <BookmarkBorder sx={{ width:22, display:"flex", alignItems:"flex-end" }} />
        <img src='https://upload.wikimedia.org/wikipedia/commons/7/78/1927_Boris_Bilinski_%281900-1948%29_Plakat_f%C3%BCr_den_Film_Metropolis%2C_Staatliche_Museen_zu_Berlin.jpg' 
        className='Today-img'
        alt='Filmplakat Metropolis'
          /> 
          <AttachMoney sx={{ width:22, display:"flex", alignItems:"flex-end" }} />
        </Box>

        <Box sx={{display:"flex", alignItems:"left"}}>
          <LocationOn sx={{ width:22, marginLeft:0.5}} />
          <Typography variant="body1" component="p" marginLeft={0.5} alignItems="left" >
           Event Discription
           </Typography>
        </Box>

           </CardContent>
        </Card>
    </Grid> */}

        <Card sx={{ maxWidth: 345 }}>
          <BookmarkBorder
            sx={{ width: 22, display: "flex", alignItems: "flex-end" }}
          />
          <CardMedia
            component="img"
            height="140"
            image="https://upload.wikimedia.org/wikipedia/commons/7/78/1927_Boris_Bilinski_%281900-1948%29_Plakat_f%C3%BCr_den_Film_Metropolis%2C_Staatliche_Museen_zu_Berlin.jpg"
            alt="Filmplakat Metropolis"
          />
          <Box sx={{ display: "flex", alignItems: "left" }}>
            <LocationOn sx={{ width: 22, marginLeft: 0.5 }} />
            <Typography
              variant="body1"
              component="p"
              marginLeft={0.5}
              alignItems="left"
            >
              Event Discription
            </Typography>
          </Box>
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Lizard
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over
              6,000 species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
          <CardActions>
            <Button size="small">Share</Button>
            <Link href="/Dashboard">
              <Button size="small">Learn More</Button>
            </Link>
          </CardActions>
        </Card>
        <Card sx={{ maxWidth: 345 }}>
          <CardMedia
            component="img"
            height="140"
            image="/static/images/cards/contemplative-reptile.jpg"
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Lizard
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over
              6,000 species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
          <CardActions>
            <Button size="small">Share</Button>
            <Link href="/Dashboard">
              <Button size="small">Learn More</Button>
            </Link>
          </CardActions>
        </Card>

        <Card sx={{ maxWidth: 345 }}>
          <CardMedia
            component="img"
            height="140"
            image="/static/images/cards/contemplative-reptile.jpg"
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Lizard
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over
              6,000 species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
          <CardActions>
            <Button size="small">Share</Button>
            <Link href="/Dashboard">
              <Button size="small">Learn More</Button>
            </Link>
          </CardActions>
        </Card>
        <Card sx={{ maxWidth: 345 }}>
          <CardMedia
            component="img"
            height="140"
            image="/static/images/cards/contemplative-reptile.jpg"
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Lizard
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over
              6,000 species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
          <CardActions>
            <Button size="small">Share</Button>
            <Link href="/Dashboard">
              <Button size="small">Learn More</Button>
            </Link>
          </CardActions>
        </Card>
        <Card sx={{ maxWidth: 345 }}>
          <CardMedia
            component="img"
            height="140"
            image="/static/images/cards/contemplative-reptile.jpg"
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Lizard
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over
              6,000 species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
          <CardActions>
            <Button size="small">Share</Button>
            <Link href="/Dashboard">
              <Button size="small">Learn More</Button>
            </Link>
          </CardActions>
        </Card>
      </Box>
    </Box>
  );
}
