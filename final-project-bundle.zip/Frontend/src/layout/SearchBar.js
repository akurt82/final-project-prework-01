import Box from "@mui/material/Box";
import { TextField, Autocomplete, Button } from "@mui/material";
import { useState } from "react";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider}  from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker }from '@mui/x-date-pickers/DatePicker';
import SearchTwoToneIcon from "@mui/icons-material/SearchTwoTone";

export default function SearchBar() {
  const [search, setSearch] = useState("Search...");
  const handleChange = (event) => {
    setSearch(event.target.value);
  };
  const [date, setDate] = useState(null);

  const CategorySearch = [
    { title: "Exbition opening", year: 1957 },
    {
      title: "performance",
      year: 2001,
    },
    { title: "Party", year: 1994 },
    { title: "House Party", year: 1972 },
    { title: "Bar Event", year: 2008 },
    { title: "Exbition", year: 1957 },
    { title: "Film ", year: 1993 },
    { title: "Concert", year: 1994 },
    { title: "Theatre", year: 1994 },
    { title: "Lecture", year: 1974 },
    {
      title: "Flea Market",
      year: 2003,
    },
   
  
  ];
  const CategoryDistance = [
    { distance: "+1km" },
    {
      distance: "+2km",
    },
    { distance: "+3km" },
    { distance: "+4km" },
    { distance: "+5km" },
    { distance: "+6km" },
    { distance: "+7km" },
    { distance: "+8km" },
    { distance: "+9km" },
    { distance: "+10km" },
    { distance: "+20km" },
    { distance: "+30km" },
    { distance: "+40km" },
    { distance: "+50km" },
    { distance: "+80km" },
    { distance: "+100km" },
    { distance: "+200km" },

  ];

  return (
    <Box
      component="form"
      sx={{
        display: "flex",
        justifyContent: "center",
        flexWrap: "wrap",
        mt: "100px",
      }}
      noValidate
      autoComplete="off"
    >
      <Box sx={{ width:"100%", display: "flex", justifyContent: "center" ,mb:"30px" }}>
        <TextField
          sx={{ width: 340, display: "flex" }}
          id="outlined-name"
          label="search"
          value={search}
          onChange={handleChange}
        /> <Button><SearchTwoToneIcon /></Button>
      </Box>
      <Box sx={{ display: "flex", justifyContent: "center", gap: "20px" }}>
        <Autocomplete
          id="filter-demo"
          options={CategoryDistance}
          getOptionLabel={(option) => option.distance}
          sx={{ width: 120, display: "flex" }}
          placeholder="distance"
          renderInput={(params) => <TextField {...params} label="distance" />}
        />
        <Autocomplete
          id="filter-demo"
          options={CategorySearch}
          getOptionLabel={(option) => option.title}
          sx={{ width: 120, display: "flex" , mb:"40px"}}
          placeholder="Category"
          renderInput={(params) => <TextField {...params} label="Category" />}
        />
       <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DatePicker
        label="Date"
        value={date}
        sx={{ width: 100, display: "flex" }}
        onChange={(newValue) => {
          setDate(newValue);
        }}
        renderInput={(params) => <TextField {...params} />}
      />
    </LocalizationProvider>
       
      </Box>
    </Box>
  );
}
