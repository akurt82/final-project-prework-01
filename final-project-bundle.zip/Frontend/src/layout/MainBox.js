import { Link } from "@mui/material";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import { createTheme, ThemeProvider, styled } from "@mui/material/styles";
import { Grid, Typography } from "@mui/material";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Button from "@mui/material/Button";
import { BookmarkBorder, AttachMoney, LocationOn } from "@mui/icons-material";

export default function MainBox() {
  return (
    <Box>
      <Typography
        sx={{
          display: "flex",
          textTransform: "uppercase",
          fontWeight: "bold",
          fontSize: 16,
          mt: "20px",
          mb:"20px",
          ml:"15px"
        }}
      >
        Recommenend event for you
      </Typography>
      <Box
        sx={{
          justifyContent: "center",
          display: "flex",
          flexWrap: "wrap",
          "& > :not(style)": {
            m: 1,
            width: 150,
            height: 150,
          },
        }}
      >
        <img
          src="https://www.goethe.de/resources/files/jpg1159/press-image-3-anselm-kiefer-essence-eksistence-artipelag-photo-jean-baptiste-beranger1-formatkey-jpg-w1022.jpg"
          className="Category-img"
          alt="Anselm Kiefer Austellung"
        />

        <img
          src="https://www.goethe.de/resources/files/jpg1159/press-image-3-anselm-kiefer-essence-eksistence-artipelag-photo-jean-baptiste-beranger1-formatkey-jpg-w1022.jpg"
          className="Category-img"
          alt="Anselm Kiefer Austellung"
        />

        <img
          src="https://www.goethe.de/resources/files/jpg1159/press-image-3-anselm-kiefer-essence-eksistence-artipelag-photo-jean-baptiste-beranger1-formatkey-jpg-w1022.jpg"
          className="Category-img"
          alt="Anselm Kiefer Austellung"
        />

        <img
          src="https://www.goethe.de/resources/files/jpg1159/press-image-3-anselm-kiefer-essence-eksistence-artipelag-photo-jean-baptiste-beranger1-formatkey-jpg-w1022.jpg"
          className="Category-img"
          alt="Anselm Kiefer Austellung"
        />
        <Paper variant="outlined" square />

        <Paper variant="outlined" square />
        <Paper variant="outlined" square />
        <Paper variant="outlined" square />
        <Paper variant="outlined" square />
        <Paper variant="outlined" square />
      </Box>

      <Typography
        sx={{
          display: "flex",
          textTransform: "uppercase",
          fontWeight: "bold",
          fontSize: 16,
          ml:"15px",
          mb:"20px",
          mt:"20px"
        }}
      >
        Today
      </Typography>
      <Box
        sx={{

          display: "flex",
          justifyContent: "space-evenly",
          gap: "10px",
          flexWrap: "wrap",
        }}
      >
        <Card sx={{ maxWidth: 345 }}>
          <CardMedia
            component="img"
            height="140"
            image="/static/images/cards/contemplative-reptile.jpg"
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Lizard
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over
              6,000 species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
          <CardActions>
            <Button size="small">Share</Button>
            <Link href="/Dashboard">
              <Button size="small">Learn More</Button>
            </Link>
          </CardActions>
        </Card>

        <Card sx={{ maxWidth: 345 }}>
          <CardMedia
            component="img"
            height="140"
            image="/static/images/cards/contemplative-reptile.jpg"
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Lizard
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over
              6,000 species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
          <CardActions>
            <Button size="small">Share</Button>
            <Link href="/Dashboard">
              <Button size="small">Learn More</Button>
            </Link>
          </CardActions>
        </Card>
        <Card sx={{ maxWidth: 345 }}>
          <CardMedia
            component="img"
            height="140"
            image="/static/images/cards/contemplative-reptile.jpg"
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Lizard
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over
              6,000 species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
          <CardActions>
            <Button size="small">Share</Button>
            <Link href="/Dashboard">
              <Button size="small">Learn More</Button>
            </Link>
          </CardActions>
        </Card>

        <Card sx={{ maxWidth: 345 }}>
          <CardMedia
            component="img"
            height="140"
            image="/static/images/cards/contemplative-reptile.jpg"
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Lizard
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over
              6,000 species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
          <CardActions>
            <Button size="small">Share</Button>
            <Link href="/Dashboard">
              <Button size="small">Learn More</Button>
            </Link>
          </CardActions>
        </Card>
        <Card sx={{ maxWidth: 345 }}>
          <CardMedia
            component="img"
            height="140"
            image="/static/images/cards/contemplative-reptile.jpg"
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Lizard
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over
              6,000 species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
          <CardActions>
            <Button size="small">Share</Button>
            <Link href="/Dashboard">
              <Button size="small">Learn More</Button>
            </Link>
          </CardActions>
        </Card>
        <Card sx={{ maxWidth: 345 }}>
          <CardMedia
            component="img"
            height="140"
            image="/static/images/cards/contemplative-reptile.jpg"
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Lizard
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Lizards are a widespread group of squamate reptiles, with over
              6,000 species, ranging across all continents except Antarctica
            </Typography>
          </CardContent>
          <CardActions>
            <Button size="small">Share</Button>
            <Link href="/Dashboard">
              <Button size="small">Learn More</Button>
            </Link>
          </CardActions>
        </Card>
      </Box>
    </Box>
  );
}
