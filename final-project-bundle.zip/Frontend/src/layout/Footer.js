import React from "react";

export default function Footer() {
  return (
    <>
      <div className="footer">
        <h6>by Abdulaziz, Neimante, Seo</h6>
      </div>
    </>
  );
}
