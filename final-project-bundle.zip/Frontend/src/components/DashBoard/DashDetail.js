import { Grid, Box, Typography, Paper } from "@mui/material";
import DashdetailCard from "./DashDetailCard";
import DashDetailDescription from "./DashDetailDescription";
import AvatarGroupItem from "./AvatarGroupItem";
import MapItem from "../../map/MapItem";
const DashDetail = () => {
  return (
    <>
      <Grid container spacing={1}>
        <Grid item xs={12} sx={{mt:"40px"}}>
          <Typography sx={{ color: "#000", fontWeight: "bold"}} p={2}>
            DETAIL INFORMATION
          </Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Box
            sx={{ width: "500px", height: "400px", m: "0 auto", p: 0 }}
            p={2}
          >
            <DashdetailCard />
          </Box>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Box  color="info.contrastText" p={1}>
           < MapItem />
          </Box>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Box
            sx={{
              width: { width: { xl: "400px", xs: "300px" } },
              height: "150px",
              m: "0 auto",
            }}
            p={2}
          >
            <AvatarGroupItem />
          </Box>
        </Grid>

        <Grid
          item
          xs={12}
          sm={6}
          sx={{ p: 2, position: "relativ", mt: " 30px" }}
        >
          <Box color="info.contrastText" p={1}>
            <DashDetailDescription />
          </Box>
        </Grid>
      

        <Grid item xs={12} sm={6}>
        <Typography sx={{ color: "#000", fontWeight: "bold" }} p={2}>
           FOTOS
          </Typography>
          <Box
            sx={{
              justifyContent: "center",
              display: "flex",
              flexWrap: "wrap",
              "& > :not(style)": {
                m: 1,
                width: 65,
                height: 65,
              },
            }}
          >
            <Paper variant="outlined" square />
            <Paper variant="outlined" square />
            <Paper variant="outlined" square />
            <Paper variant="outlined" square />
            <Paper variant="outlined" square />
            <Paper variant="outlined" square />
          
          </Box>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Box bgcolor="warning.main" color="info.contrastText" p={2}>
            코멘트
          </Box>
        </Grid>
      </Grid>
    </>
  );
};

export default DashDetail;
