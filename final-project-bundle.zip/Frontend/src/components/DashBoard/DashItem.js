import { Grid, Box, Typography } from "@mui/material";
import EventPlaceCard from "./EventPlaceCard";

import MapItem from "../../map/MapItem";

const DashItem = () => {
  return (
    
    <Grid container rowSpacing={0.5} columns={12}>
      <Grid item xs={12}>
          <Typography sx={{ color:"#000", fontWeight:"bold", mb:"20px"}} p={2} >
            SEARCH LIST
          </Typography >
        </Grid>
      <Grid xl={6} md={6} xs={12}  sx={{
          width:"100%",
          alignItems: "center",
          justifyContent: "center",
        }}>
        <Grid  width= {{ lg:"600px", xs:"85%"}} height= {{lg:"100%", xs:"300px"}}
          sx={{ alignItems:"center", m: 4}}
        >
         <MapItem />
        </Grid>
      </Grid>
      <Grid xl={6} md={6} xs={12}
        sx={{
          width:"100%",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Grid
          item
          xl={12}
          m={1}
          sx={{
            width: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <EventPlaceCard />
        </Grid>
        <Grid item xl={12} m={1} sx={{
            width: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}>
          <EventPlaceCard />
        </Grid>
        <Grid item xl={12} m={1} sx={{
            width: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}>
          <EventPlaceCard />
        </Grid>

        {/* <Grid item xl={12} bgcolor="yellow" width="400px" height="200px">3 </Grid> */}
        {/* <Grid item xl={12} bgcolor="lightgreen" width="400px" height="200px">4</Grid> */}
      </Grid>
    </Grid>
  );
};
export default DashItem;
