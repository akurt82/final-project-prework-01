import React from "react";
import Card from "@mui/material/Card";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import Grid from "@mui/material/Grid";
import Stack from "@mui/material/Stack";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Link from "@mui/material/Link";
import Divider from "@mui/material/Divider";
import Chip from "@mui/material/Chip";
import { styled } from "@mui/material/styles";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import LanguageOutlinedIcon from "@mui/icons-material/LanguageOutlined";
import GradeRoundedIcon from "@mui/icons-material/GradeRounded";
import PhoneIcon from "@mui/icons-material/Phone";
import PlaceIcon from "@mui/icons-material/Place";
import PlagiarismOutlinedIcon from "@mui/icons-material/PlagiarismOutlined";
import ShareOutlinedIcon from "@mui/icons-material/ShareOutlined";
import { useState } from "react";

const MyChip = styled(Chip)(() => ({
  borderRadius: "4px",
  marginRight: "8px",
  marginBottom: "12px"
}));


function DashdetailCard() {
  
  const [anchorEl, setAnchorEl] = useState(false);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(false);
  };
 

  return (
    <Card
      sx={{
        width:"700px",
        height:"400px",
        padding: 2,
        maxWidth: 500,
        alignItems:"center",
        m:"0 auto"
      }}
    >
      <Grid container spacing={2}>
        {/* Image */}
        <Grid item xs={12}>
          <CardMedia
            component="img"
            height="80%"
            image="https://www.berlinerfestspiele.de/media/2022/gropius-bau-2022/louise-bourgeois-the-woven-child/gb22_louise_bourgeois_spider_teaser_1120w.jpg"
            sx={{ borderRadius: 0.5 }}
          />
        </Grid>
      </Grid>

   {/* Card Content */}
   <Grid item xs={8}>
          <CardContent
            sx={{
              padding: "16px",
              margin: "8px",
              width: "465px",
              height: "100px",
              position: "absolute",
              mt: "-50px",
            }}
          >
            <Stack sx={{ mx: -2 }} spacing={0.5}>
              <Box>
                <Typography
                  variant="body1"
                  component="subtitle1"
                  sx={{ position: "absolute", left: "0", top: "0" }}
                >
                  Groupius Bau
                </Typography>
                <Box sx={{ alignItems: "center", mt: 2, mr:3}}>
                  <PlaceIcon fontSize="small" color="error" />
                  <Link href="#" variant="body2">
                   Niederkirchnerstraße 7, 10963 Berlin
                  </Link>
                </Box>
              </Box>

              {/* Card Actions */}
             
            </Stack>

            {/* Skinny Menu */}
            <MoreVertIcon
              sx={{
                cursor: "pointer",
                position: "absolute",
                right: 0,
                top: 0
              }}
              fontSize="small"
              onClick={handleClick}
            ></MoreVertIcon>
            <Menu
              anchorEl={anchorEl}
              open={open}
              onClose={handleClose}
              elevation={3}
              autoFocus={false}
              anchorOrigin={{
                vertical: "center",
                horizontal: "center"
              }}
              transformOrigin={{
                vertical: "top",
                horizontal: "right"
              }}
            >
              <MenuItem
                onClick={handleClose}
                sx={{ pb: "0", pt: "0", fontSize: "14px" }}
              >
                <ShareOutlinedIcon fontSize="small" sx={{ mr: 1 }} /> Share
              </MenuItem>
            </Menu>
          </CardContent>
        </Grid>


    </Card>
  );
}

export default DashdetailCard;
