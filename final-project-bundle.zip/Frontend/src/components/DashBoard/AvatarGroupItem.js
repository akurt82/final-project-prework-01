import React from "react";
import Avatar from "@mui/material/Avatar";
import AvatarGroup from "@mui/material/AvatarGroup";
import { Grid, Box, Typography, Button } from "@mui/material";

function AvatarGroupItem() {
  return (
    <Grid container spacing={1} xs={{maxWidth:" 500px",
      margin:" 0 auto"}}>
      <Grid item xs={12} >
        <Typography sx={{ color:"#000", fontWeight:"bold", fontSize:"10px"}}>
          LEADER
        </Typography>
      </Grid>
      <Grid container  >
      <Grid item xs={8} sx={{p:1}} >
        <Avatar alt="Travis Howard" src="/static/images/avatar/2.jpg" />
      </Grid>
      <Grid item xs={4}  >
        <Button>Join</Button>
      </Grid>
      </Grid>

      <Grid item={12} >
      
          <Typography sx={{ color:"#000", fontWeight:"bold", fontSize:"10px", mb:1}}>VISITOR</Typography>
          <AvatarGroup total={100}>
            <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
            <Avatar alt="Travis Howard" src="/static/images/avatar/2.jpg" />
            <Avatar alt="Agnes Walker" src="/static/images/avatar/4.jpg" />
            <Avatar alt="Trevor Henderson" src="/static/images/avatar/5.jpg" />
            <Avatar alt="Agnes Walker" src="/static/images/avatar/5.jpg" />
            <Avatar alt="Trevor Henderson" src="/static/images/avatar/5.jpg" />
          </AvatarGroup>
       
      </Grid>
    </Grid>
  );
}

export default AvatarGroupItem;
