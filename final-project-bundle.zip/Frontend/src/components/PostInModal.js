import React from "react";
import {
  Box,
  Stack,
  TextField,
  Divider,
  Container,
  Button,
  Typography,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import EditIcon from "@mui/icons-material/Edit";
import ClearIcon from "@mui/icons-material/Clear";
import { useState } from "react";
import Axios from "axios";

import MapSearchLeaflet from "../map/MapSearchLeaflet";
// import SearchLocation from "../map/SearchLocation";
// import Try from "./Try";



function PostInModal(props) {
  //   const [nameValue, setNameValue] = useState("");
  // const { selectLocation } = props
  // const [LeafletSearchProps, setLeafletSearchProps]=useState(null)
  const [event, setEvent] = useState("");
  const [inputData, setInputData] = useState({
    title: "",
    date: "",
    location: "",
    image:"",
    description: "",
    maxNumber: "",
  });

  const url = "http://localhost:3000/create";

  const handleSubmit = async (e) => {
    e.preventDefault();
    // await setEvent({ infos: [...inputData]})
    Axios.post(url, {
      name: inputData.title,
      date: inputData.date,
      maxNumber: inputData.userNumber,
      place: inputData.place,
      description: inputData.description,
    }).then((res) => {
      console.log(res.data);
    });
  };

  const handleChange = (e) => {
    const newData = { ...inputData };
    // 이전 데이타에 더 추가한다는 말 -> 다시한번 물어볼 것.
    newData[e.target.name] = e.target.value;
    console.log(newData);
    setInputData(newData);
  };
 
const handleAdd = () => {
        setInputData([
          ...inputData,
          {
            title: "",
            date:"",
            image: "",
            description: "",
            location: "",
            MaxNumber:""
          }
        ])
      }
  

  return (
    <Container sx={{height:"100%"}}>
      <form onSubmit={(e) => handleSubmit(e)}>
        <Stack>
          <Typography sx={{ fontWeight: "bold", textAlign: "center", mb: 2 }}>
            {" "}
            Creat your Event{" "}
          </Typography>
          <TextField sx={{m:0.5}}
            onChange={handleChange}
            placeholder="title"
            type="text"
            value={inputData.title}
            name="title"
          />
          <TextField sx={{m:0.5}}
            onChange={handleChange}
            placeholder="date"
            required
            type="date"
            value={inputData.date}
            name="date"
          />

          {/* <TextField sx={{m:0.5}}
            onChange={handleChange}
            placeholder="location"
            required
            type="text"
            value={inputData.location}
            name="location"
          /> */}
          {/* <Try /> */}
          <MapSearchLeaflet />
          <TextField sx={{m:0.5}}
            name="image"
            required
            label="Add Event Image"
            onChange={handleChange}
            value={inputData.image}
          />

          <TextField sx={{m:0.5}}
            onChange={handleChange}
            multiline
            rows={6}
            placeholder="description"
            type="text"
            value={inputData.description}
            name="description"
          />
          <TextField sx={{m:1}}
            onChange={handleChange}
            placeholder="Limit People Number"
            type="number"
            value={inputData.MaxNumber}
            name="maxNumber"
          />
          <Box sx={{display:"flex", justifyContent:"center"}}>
          <Button type="submit" onClick={handleAdd}>Send</Button>
          </Box>
        </Stack>
      </form>
    </Container>
    // <Container maxWidth="xs">
    //   <h4>Add Event</h4>
    //   <form>
    //     <Stack spacing={2}>
    //       <TextField
    //       // name="name"
    //       // required
    //       // fullWidth
    //       // label="Story Name"
    //       // onChange={(event) => handleName(event)}
    //       // value={name}
    //       />
    //       <Divider sx={{ marginBottom: 10, marginTop: 20 }} />
    //       <h4>Add Locations</h4>
    //       {inputFields.map((item, index) => (
    //         <div key={index}>
    //           <InputRow
    //           // inputFields={inputFields}
    //           // index={index}
    //           // item={item}
    //           // handleChange={handleChange}
    //           // handleRemove={handleRemove}
    //           // handleAdd={handleAdd}
    //           />
    //           <Divider sx={{ marginBottom: 10 }} />
    //         </div>
    //       ))}
    //       <Button type="submit" variant="contained" disableElevation>
    //         Send
    //       </Button>
    //       <Button disableElevation>Cancel</Button>
    //     </Stack>
    //   </form>
    // </Container>
  );
}

export default PostInModal;
