import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import { useRef, useState } from "react";
import AddEvent from "./AddEvent";
import { height } from "@mui/system";
import Button from '@mui/material/Button';

const Calendar = () => {
  const [eventAddModal, setEventAddModal] = useState(false);
  // const calendarRef = useRef(null);
  // const onEventAdded = (event) => {
  //   let calendarApi = calendarRef.current.getApi();
  //   calendarApi.AddEvent(event);
  // };

  return (
    <>
     
      <div style={{ position: "relative", zIndex: 0 }}>
        <FullCalendar 
          // ref={calendarRef}
          plugins={[dayGridPlugin]}
          initialView="dayGridMonth"
        />
      </div>
      <Button sx={{mt:2}}variant="outlined" >
        Event Creat
      </Button>
      {/* <AddEvent
        isOpen={eventAddModal}
        onClose={() => setEventAddModal(false)}
        onEventAdded={(event) => onEventAdded(event)}
      /> */}
    </>
  );
};

export default Calendar;
