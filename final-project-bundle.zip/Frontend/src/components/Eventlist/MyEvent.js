import {
  Grid,
  Box,
  Card,
  CardActions,
  CardContent,
  Button,
  Typography,
} from "@mui/material";
import { fontSize } from "@mui/system";
import Checkbox from "@mui/material/Checkbox";
import Calendar from "./Calendar";
import MyListCard from "./MyListCard";

const MyEvent = () => {
  const label = { inputProps: { "aria-label": "Checkbox demo" } };
  return (
    <>
      <Grid container spacing={10}>
        <Grid item sm={12}>
          {" "}
          mylist title
        </Grid>

        <Grid item xs={12} sm={6} spacing={2}>
          {/* <Box bgcolor="warning.main" color="info.contrastText" p={2} width="600px" height="600px"> */}
          <Calendar />
        </Grid>
        <Grid item xs={12} sm={6} spacing={2}>
          <Grid item xs={12} sm={6} sx={{
            mb:2 ,
          width:"100%",
          alignItems: "center",
          justifyContent: "center",
        }}>
            <MyListCard />
          </Grid>

          <Grid item xs={12} sm={6} sx={{
            mb:2 ,
          width:"100%",
          alignItems: "center",
          justifyContent: "center",
        }}>
            <MyListCard />
          </Grid>
          <Grid item xs={12} sm={6} sx={{
            mb:2 ,
          width:"100%",
          alignItems: "center",
          justifyContent: "center",
        }}>
            <MyListCard />
          </Grid>
          <Grid item xs={12} sm={6} sx={{
            mb:2 ,
          width:"100%",
          alignItems: "center",
          justifyContent: "center",
        }}>
            <MyListCard />
          </Grid>
      
        </Grid>
      </Grid>
    </>
  );
};

export default MyEvent;
