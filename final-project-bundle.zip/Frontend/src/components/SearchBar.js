import "../App.css";
import { makeStyles } from "@mui/styles";
import { Typography, Container } from "@mui/material";
import SearchTwoToneIcon from "@mui/icons-material/SearchTwoTone";
import "./SearchBar.css";

const SearchBar = () => {
  // const useStyles = makeStyles((theme) => ({

  // }));
  // const classes = useStyles();
  return (
    <>
      <form className="search-box-container">
        <label htmlFor="search-image-query">
          <span className="label-search"></span>
        </label>
        <input
          className="input-search"
          type="search"
          name="search-image-query"
          placeholder="Search"
          // onChange={handleChange}
        />
        <SearchTwoToneIcon />
      </form>
    </>
  );
};

export default SearchBar;
