import {
  Grid,
  Box,
  Typography,
  Button,
  TextField,
  FormControl,
  Select,
  MenuItem,
  InputLabel,
} from "@mui/material";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Avatar from "@mui/material/Avatar";
import PhotoCameraIcon from "@mui/icons-material/PhotoCamera";
import CreateIcon from "@mui/icons-material/Create";
import DoneIcon from "@mui/icons-material/Done";
import Badge from "@mui/material/Badge";
import Switch from "@mui/material/Switch";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import com from "./../bridge/fetch.js";
import { useLayoutEffect } from "react";

const SettingItem = () => {

  useLayoutEffect(
    () =>
    {
      const desc = document.getElementById("outlined-name");
      const fname = document.getElementById("fname");
      const sname = document.getElementById("lname");
      const email = document.getElementById("email");
      const phone = document.getElementById("phone");
      const city = document.getElementById("city");
      const pcode = document.getElementById("pcode");
      // *** //
      const uid = sessionStorage.getItem("userid");
      // *** //
      com(
        `http://localhost:3004/${uid}`,
        function(json){
          fname.value = json[0].fname;
          sname.value = json[0].sname;
          email.value = json[0].email;
          phone.value = json[0].phone;
          city.value = json[0].location;
          pcode.value = json[0].pcode;
          desc.value = json[0].aboutme;
          // *** //
          fname.placeholder = "";
          sname.placeholder = "";
          email.placeholder = "";
          phone.placeholder = "";
          city.placeholder = "";
          pcode.placeholder = "";
          desc.placeholder = "";
        }
      );
      // *** //
      let lang = document.getElementById("langlist");
      const mode = document.getElementById("dmode");
      const show = document.getElementById("showc");
      // *** //
      com(
        `http://localhost:3004/setup/loadgen/${uid}`,
        function(json){
          if ( json[0].langkey === "de" )
            lang.innerHTML = "German";
          else
            lang.innerHTML = "English";
          // *** //
          mode.checked = json[0].style;
          show.checked = json[0].showcomments;
        }
      );
    }, []
  );

  return (
    <>
      <Box>
        <Typography variant="h4">SETTING</Typography>
      </Box>
      <Grid container columns={12} >
        <Grid item xs={4} sx={{ m: "0 auto", mt: 3 }}>
          <Box sx={{ width: "500px", height: "400px", m: "0 auto", p: 0 }}
            p={2}>
          <Card sx={{ width: 420 }}>
            <Typography sx={{ fontSize: "10px", fontWeight: "bold", p: 2 }}>
              Profile Setting
            </Typography>
            <Grid item sx={{ p: "1.5rem 0rem", textAlign: "center" }}>
              {/* PROFILE PHOTO */}
              <Badge
                overlap="circular"
                anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                badgeContent={
                  <PhotoCameraIcon
                    id="photo"
                    sx={{
                      border: "5px solid white",
                      backgroundColor: "#ff558f",
                      borderRadius: "50%",
                      padding: ".2rem",
                      width: 35,
                      height: 35,
                    }}
                  ></PhotoCameraIcon>
                }
              >
                {" "}
                <Avatar
                  id="avatar"
                  sx={{ width: 100, height: 100, mb: 1.5 }}
                  src="https://openclipart.org/image/800px/247319"
                ></Avatar>
              </Badge>
              <Typography id="uname">userName</Typography>
            </Grid>

            <CardContent>
              <TextField
                id="outlined-name"
                label="status"
                size="small" // value={name}
                // onChange={handleChange}
              />{" "}
              <Button sx={{ ml: 1 }}>
                <CreateIcon />
              </Button>
              <Button>
                <DoneIcon />
              </Button>
              <TextField
                id="fname"
                label="First Name"
                variant="standard"
                sx={{ width: "50%" }}
              />
              <TextField
                id="lname"
                label="Last Name"
                variant="standard"
                sx={{ width: "50%" }}
              />
              <br />
              <TextField
                id="email"
                label="Email (Optional)"
                variant="standard"
                sx={{ width: "100%" }}
              />
              <br />
              <TextField
                id="phone"
                label="Phone Number"
                variant="standard"
                sx={{ width: "100%" }}
              />
              <TextField
                id="city"
                label="City"
                variant="standard"
                sx={{ width: "100%" }}
              />
              <TextField
                id="pcode"
                label="PostNumber"
                variant="standard"
                sx={{ width: "100%" }}
              />
            </CardContent>
            <CardActions>
              <Button variant="contained" sx={{ m: 1.5, ml: 3 }} size="small"
                onClick={() => {
                  const avatar = document.querySelector("#avatar img").src;
                  const desc = document.getElementById("outlined-name").value;
                  const fname = document.getElementById("fname").value;
                  const sname = document.getElementById("lname").value;
                  const email = document.getElementById("email").value;
                  const phone = document.getElementById("phone").value;
                  const city = document.getElementById("city").value;
                  const pcode = document.getElementById("pcode").value;

                  const uid = sessionStorage.getItem("userid");

                  com(
                    `http://localhost:3004/setup/user/${uid}/${fname}/${sname}/${email}/${phone}/${city}/${pcode}/${desc}`,
                    function(e){}
                  );
                }}
                >
                Save
              </Button>
            </CardActions>
          </Card>
          </Box>
        </Grid>
        <Grid item xs={7}>
          <Grid item xs={5} sx={{ m: "0 auto", mt: 3 }}>
          <Box sx={{ width: "500px", height: "400px", m: "0 auto", p: 0 }}
            p={2}> 
            <Card sx={{ minWidth: 1, maxWidth: 360, width: 420 }}>
              <Typography sx={{ fontSize: "10px", fontWeight: "bold", p: 2 }}>
                display Setting
              </Typography>

              <CardContent
                sx={{ display: " flex", justifyContent: " space-between" }}
              >
                <Typography sx={{ fontSize: "13px", fontWeight: "bold", p: 2 }}>
                  Language
                </Typography>{" "}
                <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
                  <InputLabel id="demo-select-small">Language</InputLabel>
                  <Select
                    labelId="demo-select-small"
                    id="langlist"
                    // value={age}
                    label="county"
                    // onChange={handleChange}
                  >
                    <MenuItem value={10}> German </MenuItem>
                    <MenuItem value={20}> English</MenuItem>
                  </Select>
                </FormControl>
              </CardContent>
              <CardContent
                sx={{ display: " flex", justifyContent: " space-between" }}
              >
                <Typography sx={{ fontSize: "13px", fontWeight: "bold", p: 2 }}>
                  Darkmode
                </Typography>{" "}
                <FormGroup>
                  <FormControlLabel
                    control={<Switch defaultChecked id="dmode" />}
                    label=""
                  />
                </FormGroup>
              </CardContent>
              <CardContent
                sx={{
                  display: " flex",
                  justifyContent: " space-between",
                  m: 0,
                }}
              >
                <Typography sx={{ fontSize: "13px", fontWeight: "bold", p: 2 }}>
                  Show Comment
                </Typography>{" "}
                <FormGroup>
                  <FormControlLabel
                    control={<Switch defaultChecked id="showc" />}
                    label=""
                  />
                </FormGroup>
              </CardContent>

            </Card>
            </Box>
            <Box >
                <Button variant="contained" sx={{ m: 1.5, ml: 3 }} size="small"
                onClick={() => {
                  let lang = document.getElementById("langlist").innerHTML;
                  const mode = document.getElementById("dmode").checked;
                  const show = document.getElementById("showc").checked;

                  if ( lang.trim()[0] === 'G' || lang.trim()[0] === 'D' )
                    lang = "de";
                  else
                    lang = "en";

                  const uid = sessionStorage.getItem("userid");

                  com(
                    `http://localhost:3004/setup/general/${uid}/${mode}/${lang}/${show}/0/0/0`,
                    function(e){}
                  );
                }}
                >
                  Save
                </Button>
                <Button variant="contained" sx={{ m: 1.5, ml: 3 }} size="small"
                onClick={() => {
                  const uid = sessionStorage.getItem("userid");

                  com(
                    `http://localhost:3004/setup/general/${uid}/false/en/false/0/0/0`,
                    function(e){}
                  );
                }}
                >
                  Discard
                </Button>
              </Box>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default SettingItem;
