const Category = () => {
  return (
    <></>
  )
}

export default Category;