/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * HTTP Interaction
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

const express = require('express');
const app = express();
//const svr = express();
//const app = express.Router();
app.use(express.json());
//router.use(express.json());

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Portnummer
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

const port = 3004;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * CORS
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

//const cors = require('cors');

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * App Use
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

//svr.use(cors());
//app.use(cors());
//router.use(cors());

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Router
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

const pageHome = require('./route/home.js');

app.get('/', (req, res, next) => {
	pageHome.get( req, res, next );
});
app.get('/:id', (req, res, next) => {
	pageHome.getSpec( req.params.id, req, res, next );
});

const pageLogin = require('./route/login.js');
app.get('/login/:user/:pass', (req, res, next) => {
	pageLogin.get( req.params.user, req.params.pass, req, res, next );
});
const pageRegister = require('./route/register.js');
app.get('/register/:fn/:ln/:em/:ps/:mn/:ct/:pn', (req, res, next) => {
	pageRegister.get( 
		req.params.fn,
		req.params.ln,
		req.params.em,
		req.params.ps,
		req.params.mn,
		req.params.ct,
		req.params.pn,
		req, res, next );
});

const pageSetup = require('./route/setup.js');
app.get('/setup/:id', (req, res, next) => {
	pageSetup.get( req.params.id, req, res, next );
});
app.get('/setup/loadgen/:uid', (req, res, next) => {
	pageSetup.getGeneral( req.params.uid, req, res, next );
});
app.get('/setup/general/:uid/:style/:langkey/:shcom/:evno/:meno/:lono', (req, res, next) => {
	pageSetup.setGeneral( 
		req.params.uid, 
		req.params.style,
		req.params.langkey,
		req.params.shcom,
		req.params.evno,
		req.params.meno,
		req.params.lono,
		req, res
	);
});
app.get('/setup/user/:id/:fn/:ln/:em/:mn/:ct/:pn/:de', (req, res, next) => {
	pageSetup.setUser( 
		req.params.id,
		req.params.fn,
		req.params.ln,
		req.params.em,
		req.params.mn,
		req.params.ct,
		req.params.pn,
		req.params.de,
		req, res, next );
});

const pageReminder = require('./route/reminder.js');
app.get('/reminder', (req, res, next) => {
	pageReminder.get( req, res, next );
});

const pageMessage = require('./route/message.js');
app.get('/message', (req, res, next) => {
	pageMessage.get( req, res, next );
});
app.get('/message/friendlist/:id', (req, res, next) => {
	pageMessage.getFriends( req.params.id, req, res, next );
});
app.get('/message/reminderoptions/:id', (req, res, next) => {
	pageMessage.getReminderOptions( req.params.id, req, res, next );
});
app.get('/message/share/:uid/:fid', (req, res, next) => {
	pageMessage.getShare( req.params.uid, req.params.fid, req, res, next );
});
app.get('/message/send/:uid/:fid/:msg', (req, res, next) => {
	pageMessage.getSend( req.params.uid, req.params.fid, req.params.msg, req, res, next );
});
app.get('/message/notify/:uid/:fid/:rid', (req, res, next) => {
	pageMessage.getNotifyFriend( req.params.uid, req.params.fid, req.params.rid, req, res, next );
});

const pageNotification = require('./route/notification.js');
app.get('/notification/show/:part/:uid', (req, res, next) => {
	pageNotification.get( req.params.part, req.params.uid, req, res, next );
});
app.get('/notification/list/:uid', (req, res, next) => {
	pageNotification.getList( req.params.uid, req, res, next );
});
app.get('/notification/save/:uid/:ontype/:onday/:onweek/:onregion/:ontitle/:onmessage', (req, res, next) => {
	pageNotification.set( 
	req.params.uid,
	req.params.ontype,
	req.params.onday,
	req.params.onweek,
	req.params.onregion,
	req.params.ontitle,
	req.params.onmessage,
	req, res, next );
});
app.get('/notification/remove/entry/:id', (req, res, next) => {
	pageNotification.remove( req.params.id, req, res, next );
});
app.get('/notification/notify/get/:uid', (req, res, next) => {
	pageNotification.getNotify( req.params.uid, req, res, next );
});
app.get('/notification/notify/set/:uid/:onevent/:onmessage/:onlocation', (req, res, next) => {
	pageNotification.setNotify( 
	req.params.uid, 
	req.params.onevent,
	req.params.onmessage,
	req.params.onlocation,
	req, res, next );
});

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Server-Verbindung aufbauen
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

app.listen(port, () => {
	console.log(`Listening on port ${port}`);
});
